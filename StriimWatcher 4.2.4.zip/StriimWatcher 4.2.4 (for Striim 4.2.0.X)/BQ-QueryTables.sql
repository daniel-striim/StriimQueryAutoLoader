-- Table that shows it is running, which Striim instance and how long it took
select * from `public.striim_mon_table_runhistory` order by batchdate desc;

-- mon; related information (list of applications; cluster list; and ES details)
select * from `public.striim_mon_node_applications` order by batchdate desc;
select * from `public.striim_mon_node_cluster` order by batchdate desc;
select * from `public.striim_mon_node_elasticsearch` order by batchdate desc;

-- Details of applications
select * from `public.striim_mon_appdetail` order by batchdate desc;

--Lee details, attempting to detect Source/Target Apps linked to it
select * from `public.striim_mon_lee` order by batchdate desc;

--Table-level details
select * from `public.striim_mon_table_comparison` order by batchdate desc;
select * from `public.striim_mon_table_comparison_sli` order by batchdate desc;

--Optional Tables
select * from `public.striim_mon_component_output` order by batchdate desc;
select * from `public.striim_mon_table_column_detail` order by batchdate desc;

-- Data Warehouse
select * from public.striim_mon_datawarehouse_detail order by batchdate desc;

-- Striim.server.log error tracker:
select * from public.striim_mon_log_watcher order by batchdate desc, log_date DESC;
select * from public.striim_mon_log_watcher order by log_date DESC;