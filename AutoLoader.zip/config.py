ILA_NS_BASE = "ILA"                         # Variations of this namespace will be used for staging (ILA1, ILA2, ILA3, etc)
CLEAN_NS_BASE_APPS = False                  # Determines if it should remove/clear all apps in these namespaces upon restart; True = reset; False = continue
ILA_APP_NAME_BASE = "OracleInitialLoadApp"  # This should match what is in the .tql file
CONCURRENT_APPS_MAX = 5                     # Controls the maximum number of running, quiescing, or completed apps that can run at the same time
APP_MONITOR_INTERVAL_SECONDS = 15           # Controls how often we monitor app status. Should not be less than 15 seconds.
DEPLOY_WAIT_TIME_SECONDS = 20               # Controls minimum time on how long to wait between deploying new apps, so we do not overload Striim
QUERY_FILE_PATH = "/Users/danielferrara/PycharmProjects/StriimQueryAutoLoad/queryfile.txt"  # This should be the list of queries to run with details
SOURCE_TQL_PATH = "/Users/danielferrara/PycharmProjects/StriimQueryAutoLoad/"               # Path containing the source Template TQL File
SOURCE_TQL_FILE = "admin.SW.tql"            # Source Template TQL File Name
TARGET_TQL_PATH = "/Users/danielferrara/PycharmProjects/StriimQueryAutoLoad/stage/"         # The staging location to create temporary apps based on the template
STRIIM_URL_PREFIX = "http://"               # Striim end-point; either http:// or https://
STRIIM_NODE = "localhost:9080"              # Striim node URL (i.e. localhost:9080 or mystriim:9080)
STRIIM_ADMIN_USER = "admin"                 # [Ignored if API_TOKEN provided] Username to authenticate via API
STRIIM_ADMIN_PWD = "admin"                  # [Ignored if API_TOKEN provided] Password to authenticate via API
# Can retrieve the token with a curl command: curl -X POST -d'username=admin&password=admin' http://<url>:9080/security/authenticate
STRIIM_API_TOKEN = ""                       # API Token that overrides need to provide username/password
LOG_OUTPUT_PATH = "/Users/danielferrara/Documents/striimautoloader.log"